﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineRender : MonoBehaviour
{
    LineRenderer line;
   
    public GameObject hair;
    private Rigidbody[] massPoints;
    private Transform[] hairPoints;
    private Transform startPoint;
    private Vector3[] force;
    private float rest_length=5;
    public float ks=0.3f;
    private Vector3[] v;
    // Start is called before the first frame update
    void Start()
    {
        line = GetComponent<LineRenderer>();
        hairPoints = hair.GetComponentsInChildren<Transform>();
        massPoints = hair.GetComponentsInChildren<Rigidbody>();
        startPoint = hairPoints[0];

        force = new Vector3[hairPoints.Length];
        v = new Vector3[hairPoints.Length];
        //初始化
        for(int i=0;i<hairPoints.Length;i++)
        {
            force[i] = new Vector3(0, 0, 0);
            v[i] = new Vector3(0, 0, 0);
        }
    }

    // Update is called once per frame
    void Update()
    {
       for(int i=0;i<hairPoints.Length;i++)
        {
            line.SetPosition(i, hairPoints[i].position);
        }
        
    }
    private void FixedUpdate()
    {
        //计算力
        for(int i=1;i<hairPoints.Length-1;i++)
        {
            Vector3 x1 = hairPoints[i - 1].position - hairPoints[i].position;
            Vector3 x2 = hairPoints[i + 1].position - hairPoints[i].position;
            
            force[i] += (x1.magnitude / rest_length - 1)*x1.normalized*(-ks);
            force[i] += (x2.magnitude / rest_length - 1) * x2.normalized * (-ks);

            //f[i]+=-spring_Y*(x_ij.norm()/rest_length[i,j]-1)*d


        }
        //最后一个
        Vector3 x = hairPoints[hairPoints.Length - 1].position - hairPoints[hairPoints.Length].position;
        force[hairPoints.Length]= (x.magnitude / rest_length - 1) * x.normalized * (-ks);

       for(int i=1;i<hairPoints.Length;i++)
        {
            massPoints[i].AddForce(force[i]);
        }
    }
}
