# Plastic SCM for Unity

## [1.0.0] - 2020-10-13

### This is the first release of *Unity Package Plastic SCM*.

Integrate Plastic SCM with Unity.